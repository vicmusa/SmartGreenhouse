package com.example.smartgreenhouse

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import com.google.firebase.database.FirebaseDatabase

class actuadores : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_actuadores)

        var database = FirebaseDatabase.getInstance().reference
        var aux = 0
        var aux1 = 0
        var aux2 = 0
        var aux3 = 0
        var aux4 = 0
        var aux5 = 0

        //Botones
        val Riego = findViewById<Button>(R.id.riego)
        val Ventiladores = findViewById<Button>(R.id.ventilador)
        val Calefaccion = findViewById<Button>(R.id.calefaccion)
        val manual = findViewById<Button>(R.id.manual)
        val Luz = findViewById<Button>(R.id.iluminacion)
        val aspersor = findViewById<Button>(R.id.aspersor)


        // Envio los botones
        manual.setOnClickListener {
            aux3 = 1 - aux3

            if (aux3 == 0) {

                aux = 0
                aux1 = 0
                aux2 = 0

                database.child("comandos").setValue(Boton(aux, aux1, aux2, aux3, aux4,aux5))

            }

            if (aux3 == 1) {
                database.child("comandos").setValue(Boton(aux, aux1, aux2, aux3, aux4, aux5))


            }
        }



        Riego.setOnClickListener {

            if (aux3 == 1) {
                aux = 1 - aux
                if (aux == 1) {
                    database.child("comandos").setValue(Boton(aux, aux1, aux2, aux3, aux4, aux5))

                }

                if (aux == 0) {

                    database.child("comandos").setValue(Boton(aux, aux1, aux2, aux3, aux4, aux5))


                }

            }
        }

        aspersor.setOnClickListener {

            if (aux3 == 1) {
                aux5 = 1 - aux5
                if (aux5 == 1) {
                    database.child("comandos").setValue(Boton(aux, aux1, aux2, aux3, aux4,aux5))

                }

                if (aux5 == 0) {

                    database.child("comandos").setValue(Boton(aux, aux1, aux2, aux3, aux4, aux5))


                }

            }
        }


        Ventiladores.setOnClickListener {

            if (aux3 == 1) {

                aux2 = 1 - aux2
                if (aux2 == 1) {

                    database.child("comandos").setValue(Boton(aux, aux1, aux2, aux3, aux4, aux5))

                }

                if (aux2 == 0) {

                    database.child("comandos").setValue(Boton(aux, aux1, aux2, aux3, aux4, aux5))


                }
            }

        }

        Calefaccion.setOnClickListener {
            if (aux3 == 1) {

                aux1 = 1 - aux1
                if (aux1 == 1) {

                    database.child("comandos").setValue(Boton(aux, aux1, aux2, aux3, aux4, aux5))

                }

                if (aux1 == 0) {

                    database.child("comandos").setValue(Boton(aux, aux1, aux2, aux3, aux4, aux5))


                }
            }

        }


        Luz.setOnClickListener {

            aux4 = 1 - aux4
            if (aux4 == 1) {

                database.child("comandos").setValue(Boton(aux, aux1, aux2, aux3, aux4, aux5))

            }

            if (aux4 == 0) {

                database.child("comandos").setValue(Boton(aux, aux1, aux2, aux3, aux4, aux5))


            }
        }




    }


    }
