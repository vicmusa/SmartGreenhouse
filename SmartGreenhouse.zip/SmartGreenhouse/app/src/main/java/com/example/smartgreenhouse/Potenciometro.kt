package com.example.smartgreenhouse

class Potenciometro {

    var Sensor1 = 0


    constructor(Sensor1:Int) {
        this.Sensor1 = Sensor1

    }
}